package modCubes;

import com.jme3.app.SimpleApplication;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.shape.Box;

/**
 * test
 * @author normenhansen
 */
public class Main extends SimpleApplication
{
    public static void main(String[] args)
    {
        Main app = new Main();
        CubesSettings settings = new CubesSettings(app);
        app.start();
    }

    @Override
    public void simpleInitApp()
    {
        CubesTestAssets.registerBlocks();
        CubesSettings settings = CubesTestAssets.getSettings(this);
        settings.setChunkLoadRadius(7);
        /*BlockManager.register(Block_Wood.class, new BlockSkin(new BlockSkin_TextureLocation[]{
            new BlockSkin_TextureLocation(4, 0),
            new BlockSkin_TextureLocation(4, 0),
            new BlockSkin_TextureLocation(3, 0),
            new BlockSkin_TextureLocation(3, 0),
            new BlockSkin_TextureLocation(3, 0),
            new BlockSkin_TextureLocation(3, 0)
        }, false));
        BlockManager.register(Block_Stone.class, new BlockSkin(new BlockSkin_TextureLocation(9, 0), false));
        BlockManager.register(Block_Water.class, new BlockSkin(new BlockSkin_TextureLocation(0, 1), true));
        BlockManager.register(Block_Brick.class, new BlockSkin(new BlockSkin_TextureLocation(11, 0), false));*/
        
        //This is your terrain, it contains the whole
        //block world and offers methods to modify it
        BlockTerrainControl blockTerrain = new BlockTerrainControl(settings);

        
        //The terrain is a jME-Control, you can add it
        //to a node of the scenegraph to display it
        Node terrainNode = new Node();
        terrainNode.addControl(blockTerrain);
        rootNode.attachChild(terrainNode);
        
        


        //blockTerrain.setBlock(new Vector3Int(20, 20, 20), Block_Wood.class); 
        //You can place whole areas of blocks too: setBlockArea(location, size, block)
        //(The specified block will be cloned each time)
        //The following line will set 3 blocks on top of each other
        //({1,1,1}, {1,2,3} and {1,3,1})
        blockTerrain.setBlockArea(new Vector3Int(1, 1, 1), new Vector3Int(1, 3, 1), Block_Stone.class);

        //Removing a block works in a similar way
        blockTerrain.removeBlock(new Vector3Int(1, 2, 1));
        blockTerrain.removeBlock(new Vector3Int(1, 3, 1));

        
        
        cam.setLocation(new Vector3f(-10, 10, 16));
        cam.lookAtDirection(new Vector3f(1, -0.56f, -1), Vector3f.UNIT_Y);
        flyCam.setMoveSpeed(50);
        cam.lookAt(new Vector3f(10, 10, 10), Vector3f.UNIT_Y);
        
        DirectionalLight directionalLight = new DirectionalLight();
        directionalLight.setColor(new ColorRGBA(1f, 1f, 1f, 1.0f));
        rootNode.addLight(directionalLight);
    }
    
    
    
    
    

    @Override
    public void simpleUpdate(float tpf) {
        //TODO: add update code
    }

    @Override
    public void simpleRender(RenderManager rm) {
        //TODO: add render code
    }
}
