package modCubes;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jme3.app.Application;
import com.jme3.asset.AssetManager;
import com.jme3.bullet.BulletAppState;
import com.jme3.material.Material;

/**
 *
 * @author Carl
 */
public class CubesSettings{
    
    public CubesSettings(Application application){
        app = application;
        assetManager = application.getAssetManager();
    }
    private Application app;
    private AssetManager assetManager;
    private float blockSize = 3;
    private int chunkSizeX = 16;
    private int chunkSizeY = 256;
    private int chunkSizeZ = 16;
    private int chunkLoadRadius = 7;
    private Material blockMaterial;
    private BulletAppState physics;
    private String currentGameLocation = "..\\";
    
    public Application getApp()
    {
        return app;
    }

    public AssetManager getAssetManager(){
        return assetManager;
    }
    
    public String getCurrentGameLocation()
    {
        return currentGameLocation;
    }
    
    public void setCurrentGameLocation(String s)
    {
        currentGameLocation = s;
    }

    public float getBlockSize(){
        return blockSize;
    }

    public void setBlockSize(float blockSize){
        this.blockSize = blockSize;
    }

    public int getChunkSizeX(){
        return chunkSizeX;
    }

    public void setChunkSizeX(int chunkSizeX){
        this.chunkSizeX = chunkSizeX;
    }

    public int getChunkSizeY(){
        return chunkSizeY;
    }

    public void setChunkSizeY(int chunkSizeY){
        this.chunkSizeY = chunkSizeY;
    }

    public int getChunkSizeZ(){
        return chunkSizeZ;
    }

    public void setChunkSizeZ(int chunkSizeZ){
        this.chunkSizeZ = chunkSizeZ;
    }

    public Material getBlockMaterial(){
        return blockMaterial;
    }
    
    public int getChunkLoadRadius()
    {
        return chunkLoadRadius;
    }
    public void setChunkLoadRadius(int radius)
    {
        chunkLoadRadius = radius;
    }
    
    public void setPhysics(BulletAppState p)
    {
        physics = p;
    }
    
    public BulletAppState getPhysics()
    {
        return physics;
    }

    public void setDefaultBlockMaterial(String textureFilePath){
        setBlockMaterial(new BlockChunk_Material(assetManager, textureFilePath));
    }

    public void setBlockMaterial(Material blockMaterial){
        this.blockMaterial = blockMaterial;
    }
}
