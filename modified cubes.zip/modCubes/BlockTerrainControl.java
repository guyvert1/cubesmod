package modCubes;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.jme3.bullet.collision.shapes.MeshCollisionShape;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.Vector3f;
import java.io.IOException;
import java.util.ArrayList;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Geometry;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import com.jme3.terrain.heightmap.ImageBasedHeightMap;
import com.jme3.texture.Texture;
import java.io.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This version can despawn and generate chunks, but cannot save or load them.
 * @author Modified from the file built by carl by GoblinThing
 */
public class BlockTerrainControl extends AbstractControl implements BitSerializable
{
    private CubesSettings settings;
    public ConcurrentHashMap<Vector3Int, BlockChunkControl> chunksMap;
    private ArrayList<BlockChunkListener> chunkListeners = new ArrayList<BlockChunkListener>();
    
    

    
    
    public BlockTerrainControl(CubesSettings settings)
    {
        this.chunksMap = new ConcurrentHashMap<Vector3Int, BlockChunkControl>();
        this.settings = settings;
        initializeChunks(new Vector3Int(settings.getChunkLoadRadius(), settings.getChunkLoadRadius(), settings.getChunkLoadRadius()));
    }
    
    
    private void initializeChunks(Vector3Int chunksCount)
    {
        for(int x = 0; x < chunksCount.getX(); x++)
        {
            for(int y = 0; y < chunksCount.getY(); y++)
            {
                for(int z = 0; z < chunksCount.getZ(); z++)
                {
                    addChunk(new Vector3Int(x, y, z));
                }
            }
        }
    }
    
    public void growWorld(Vector3Int location)
    {
        for(int x = -settings.getChunkLoadRadius(); x < settings.getChunkLoadRadius(); x++)
        {
            for(int y = -settings.getChunkLoadRadius(); y < settings.getChunkLoadRadius(); y++)
            {
                for(int z = -settings.getChunkLoadRadius(); z < settings.getChunkLoadRadius(); z++)
                {
                    int adjX = location.getX() + x;
                    int adjY = location.getY() + y;
                    int adjZ = location.getZ() + z;
                    Vector3Int adjVector =  new Vector3Int(adjX, adjY, adjZ);
                    if(!chunksMap.containsKey(adjVector))
                    {
                        addChunk(adjVector);
                    }
                }
            }
        }
        reduceWorld(location);
    }
        
    public void reduceWorld(Vector3Int location)
    {
        Set<Vector3Int> chunkList = chunksMap.keySet();
        for(Vector3Int coord : chunkList)
        {
            
            if(!between(coord, location, settings.getChunkLoadRadius()))
            {
                try
                {
                    despawnChunk(coord);
                }
                catch (IOException ex)
                {
                    Logger.getLogger(BlockTerrainControl.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }
    }
        
    public void addChunk(final Vector3Int location)
    {
        final BlockTerrainControl temp = this;
        settings.getApp().enqueue(new Callable<BlockChunkControl>()
        {
            public BlockChunkControl call() throws Exception
            {
                BlockChunkControl chunk = null;
                if(!chunksMap.containsKey(location))
                {
                    try
                    {
                        loadChunk(location);
                    }
                    catch (FileNotFoundException ex)
                    {
                        chunk = new BlockChunkControl(temp, location.getX(), location.getY(), location.getZ());
                        chunksMap.put(location, chunk);
                        if(temp.spatial != null)
                        {
                            temp.spatial.addControl(chunk);
                        }
                        setChunkFromNoise(location);
                    }
                    catch (IOException ex)
                    {
                        Logger.getLogger(BlockTerrainControl.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                return chunk;
            }
        });
        
    }
    
    /**
     * loads a chunk from the current coordinates.
     * If the chunk cannot be found at those coordinates, throse a FNF exception.
     * @param location 
     */
    public void loadChunk(final Vector3Int location) throws FileNotFoundException, IOException
    {
        //creates file and data input streams from which to read saved data.
        FileInputStream inputFile = new FileInputStream(settings.getCurrentGameLocation() + (location.getX() + "--" + location.getY() + "--" + location.getZ() + ".dat"));
        DataInputStream input = new DataInputStream(inputFile);
        
        //list of Bytes to store the data in.
        ArrayList<Byte> bytelist = new ArrayList<Byte>();
        
        //read the data from the given location.
        boolean EOF = false;
        while(!EOF)
        {
            try
            {
                bytelist.add(input.readByte());
            }
            catch(EOFException e)
            {
                EOF = true;
            }
        }
        
        //Convert from Byte[] to byte[]
        Byte[] bytelisttwo = bytelist.toArray(new Byte[bytelist.size()]);
        byte[] serializedTerrainData = new byte[bytelisttwo.length];
        for(int a = 0; a < bytelisttwo.length; a++)
        {
            serializedTerrainData[a] = bytelisttwo[a].byteValue();
        }
        
        //create a new chunk at the proper location.
        BlockChunkControl chunk = new BlockChunkControl(this, location.getX(), location.getY(), location.getZ());
        
        //deserialise and read the chunk.
        CubesSerializer.readFromBytes(chunk, serializedTerrainData);
        
        //add the chunk to the game.
        if(spatial != null)
        {
            spatial.addControl(chunk);
        }
        chunksMap.put(location, chunk);
        
    }
    
    /**
     * saves then despawns a chunk at the given coordinates.
     * @param location 
     */
    public void despawnChunk(Vector3Int location) throws IOException
    {
        //retreives the chunki to be despawned.
        BlockChunkControl chunk = chunksMap.get(location);
        
        //prepare a file output stream
        FileOutputStream chunkFile = null;
        
        if(chunk != null)
        {
            //retreive the byte array
            byte[] serializedTerrainData = CubesSerializer.writeToBytes(chunk);
            
            try
            {
                //create a file at the proper location with standardised file names,
                //for easy acess + retreival. Create the data output stream.
                chunkFile = new FileOutputStream(settings.getCurrentGameLocation() + (location.getX() + "--" + location.getY() + "--" + location.getZ() + ".dat"));
                DataOutputStream outputFile = new DataOutputStream(chunkFile);
                
                //write & close
                outputFile.write(serializedTerrainData);
                outputFile.close();
                
                
                //in order for this to work, we must remove the physics manually.
                //destroying all the blocks in a chunk will result in a similar error;
                //the game does not want to calculate a physics shape where there are no
                //physical objects.
                Geometry optimizedGeometry = chunk.getOptimizedGeometry_Opaque();
                if(optimizedGeometry != null)
                {
                    RigidBodyControl rigidBodyControl = optimizedGeometry.getControl(RigidBodyControl.class);
                    settings.getPhysics().getPhysicsSpace().remove(rigidBodyControl);
                    optimizedGeometry.removeControl(RigidBodyControl.class);
                }
                
                //remove the chunk data from the data management system.
                if(this.spatial != null)
                {
                    spatial.removeControl(chunksMap.get(location));
                }
                chunksMap.remove(location);
            }
            catch (FileNotFoundException ex)
            {
                Logger.getLogger(BlockTerrainControl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    
    
    public boolean between(Vector3Int a, Vector3Int b, int radius)
    {
        int aX = a.getX();
        int aY = a.getY();
        int aZ = a.getZ();
        
        int bX = b.getX();
        int bY = b.getY();
        int bZ = b.getZ();
        if(aX >= bX - radius && aX < bX + radius)
        {
            if(aY >= bY - radius && aY <= bY + radius)
            {
                if(aZ >= bZ - radius && aZ <= bZ + radius)
                {
                    return true;
                }
            }
            
        }
        return false;
    }
    
    public boolean between(int a, int b, int c)
    {
        boolean between = false;
        if(a >= b && a <= c)
        {
            between = true;
        }
        return between;
    }
    
    
    


    //TODO: find out what this does.
    @Override
    public void setSpatial(Spatial spatial)
    {
        Spatial oldSpatial = this.spatial;
        super.setSpatial(spatial);
        System.out.println(spatial);
        
        Set<Vector3Int> keySet = chunksMap.keySet();
        for(Vector3Int key : keySet)
        {
            if(spatial == null)
            {
                oldSpatial.removeControl(chunksMap.get(key));
            }
            else
            {
                spatial.addControl(chunksMap.get(key));
            }
        }
        /*
         * //old code
        for(int x=0;x<chunks.length;x++)
        * {
            for(int y=0;y<chunks[0].length;y++)
            * {
                for(int z=0;z<chunks[0][0].length;z++)
                * {
                    if(spatial == null)
                    {
                        oldSpatial.removeControl(chunksMap);
                    }
                    else
                    {
                        spatial.addControl(chunks[x][y][z]);
                    }
                }
            }
        }*/
    }

    @Override
    protected void controlUpdate(float lastTimePerFrame)
    {
        updateSpatial();
    }

    @Override
    protected void controlRender(RenderManager renderManager, ViewPort viewPort){
        
    }

    @Override
    public Control cloneForSpatial(Spatial spatial){
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public BlockType getBlock(int x, int y, int z){
        return getBlock(new Vector3Int(x, y, z));
    }
    
    public BlockType getBlock(Vector3Int location)
    {
        BlockTerrain_LocalBlockState localBlockState = getLocalBlockState(location);
        if(localBlockState != null)
        {
            return localBlockState.getBlock();
        }
        return null;
    }
    
    public void setBlockArea(Vector3Int location, Vector3Int size, Class<? extends Block> blockClass){
        Vector3Int tmpLocation = new Vector3Int();
        for(int x=0;x<size.getX();x++){
            for(int y=0;y<size.getY();y++){
                for(int z=0;z<size.getZ();z++){
                    tmpLocation.set(location.getX() + x, location.getY() + y, location.getZ() + z);
                    setBlock(tmpLocation, blockClass);
                }
            }
        }
    }
    
    public void setBlock(int x, int y, int z, Class<? extends Block> blockClass){
        setBlock(new Vector3Int(x, y, z), blockClass);
    }
    
    public void setBlock(Vector3Int location, Class<? extends Block> blockClass)
    {
        BlockTerrain_LocalBlockState localBlockState = getLocalBlockState(location);
        if(localBlockState != null)
        {
            localBlockState.setBlock(blockClass);
        }
    }
    
    public void removeBlockArea(Vector3Int location, Vector3Int size){
        Vector3Int tmpLocation = new Vector3Int();
        for(int x=0;x<size.getX();x++){
            for(int y=0;y<size.getY();y++){
                for(int z=0;z<size.getZ();z++){
                    tmpLocation.set(location.getX() + x, location.getY() + y, location.getZ() + z);
                    removeBlock(tmpLocation);
                }
            }
        }
    }
    
    public void removeBlock(int x, int y, int z){
        removeBlock(new Vector3Int(x, y, z));
    }
    
    public void removeBlock(Vector3Int location){
        BlockTerrain_LocalBlockState localBlockState = getLocalBlockState(location);
        if(localBlockState != null){
            localBlockState.removeBlock();
        }
    }
    
    private BlockTerrain_LocalBlockState getLocalBlockState(Vector3Int blockLocation)
    {
        //if(blockLocation.hasNegativeCoordinate())
        //{
        //    return null;
        //}
        BlockChunkControl chunk = getChunk(blockLocation);
        if(chunk != null)
        {
            Vector3Int localBlockLocation = getLocalBlockLocation(blockLocation, chunk);
            return new BlockTerrain_LocalBlockState(chunk, localBlockLocation);
        }
        return null;
    }
    
    public BlockChunkControl getChunk(Vector3Int blockLocation)
    {
        Vector3Int chunkLocation = getChunkLocation(blockLocation);
        if(isValidChunkLocation(chunkLocation))
        {
            return chunksMap.get(chunkLocation);
        }
        return null;
        /*
         * //old chunk
        if(blockLocation.hasNegativeCoordinate())
        {
            return null;
        }
        Vector3Int chunkLocation = getChunkLocation(blockLocation);
        if(isValidChunkLocation(chunkLocation))
        {
            return chunks[chunkLocation.getX()][chunkLocation.getY()][chunkLocation.getZ()];
        }*/
    }
    
    private boolean isValidChunkLocation(Vector3Int location)
    {
        if(chunksMap.get(location) != null)
        {
            return true;
        }
        return false;
    }
    
    private Vector3Int getChunkLocation(Vector3Int blockLocation)
    {
        Vector3Int chunkLocation = new Vector3Int();
        int chunkX = (blockLocation.getX() / settings.getChunkSizeX());
        int chunkY = (blockLocation.getY() / settings.getChunkSizeY());
        int chunkZ = (blockLocation.getZ() / settings.getChunkSizeZ());
        chunkLocation.set(chunkX, chunkY, chunkZ);
        return chunkLocation;
    }
    
    public static Vector3Int getLocalBlockLocation(Vector3Int blockLocation, BlockChunkControl chunk){
        Vector3Int localLocation = new Vector3Int();
        int localX = (blockLocation.getX() - chunk.getBlockLocation().getX());
        int localY = (blockLocation.getY() - chunk.getBlockLocation().getY());
        int localZ = (blockLocation.getZ() - chunk.getBlockLocation().getZ());
        localLocation.set(localX, localY, localZ);
        return localLocation;
    }
    
    public boolean updateSpatial()
    {
        boolean wasUpdatedNeeded = false;
        Set<Vector3Int> keySet = chunksMap.keySet();
        for(Vector3Int key : keySet)
        {
            BlockChunkControl chunk = chunksMap.get(key);
            if(chunk.updateSpatial())
            {
                wasUpdatedNeeded = true;
                for(int i=0;i<chunkListeners.size();i++)
                {
                    BlockChunkListener blockTerrainListener = chunkListeners.get(i);
                    blockTerrainListener.onSpatialUpdated(chunk);
                }
            }
        }
        
        
        
        
        /*
         * boolean wasUpdatedNeeded = false;
        for(int x=0;x<chunks.length;x++)
        {
            for(int y=0;y<chunks[0].length;y++)
            {
                for(int z=0;z<chunks[0][0].length;z++)
                {
                    BlockChunkControl chunk = chunks[x][y][z];
                    if(chunk.updateSpatial())
                    {
                        wasUpdatedNeeded = true;
                        for(int i=0;i<chunkListeners.size();i++)
                        {
                            BlockChunkListener blockTerrainListener = chunkListeners.get(i);
                            blockTerrainListener.onSpatialUpdated(chunk);
                        }
                    }
                }
            }
        }*/
        return wasUpdatedNeeded;
    }
    
    public void updateBlockMaterial()
    {
        Set<Vector3Int> keySet = chunksMap.keySet();
        for(Vector3Int key : keySet)
        {
            
            chunksMap.get(key).updateBlockMaterial();
        }
        
        /*
         * //old code
        for(int x=0;x<chunks.length;x++)
        {
            for(int y=0;y<chunks[0].length;y++)
            {
                for(int z=0;z<chunks[0][0].length;z++)
                {
                    chunks[x][y][z].updateBlockMaterial();
                }
            }
        }*/
    }
    
    public void addChunkListener(BlockChunkListener blockChunkListener){
        chunkListeners.add(blockChunkListener);
    }
    
    public void removeChunkListener(BlockChunkListener blockChunkListener){
        chunkListeners.remove(blockChunkListener);
    }
    
    public CubesSettings getSettings()
    {
        return settings;
    }

    //Tools
    
    public void setBlocksFromHeightmap(Vector3Int location, String heightmapPath, int maximumHeight, Class<? extends Block> blockClass){
        try{
            Texture heightmapTexture = settings.getAssetManager().loadTexture(heightmapPath);
            ImageBasedHeightMap heightmap = new ImageBasedHeightMap(heightmapTexture.getImage(), 1f);
            heightmap.load();
            heightmap.setHeightScale(maximumHeight / 255f);
            setBlocksFromHeightmap(location, getHeightmapBlockData(heightmap.getScaledHeightMap(), heightmap.getSize()), blockClass);
        }catch(Exception ex){
        }
    }

    private static int[][] getHeightmapBlockData(float[] heightmapData, int length){
        int[][] data = new int[heightmapData.length / length][length];
        int x = 0;
        int z = 0;
        for(int i=0;i<heightmapData.length;i++){
            data[x][z] = (int) Math.round(heightmapData[i]);
            x++;
            if((x != 0) && ((x % length) == 0)){
                x = 0;
                z++;
            }
        }
        return data;
    }

    public void setBlocksFromHeightmap(Vector3Int location, int[][] heightmap, Class<? extends Block> blockClass){
        Vector3Int tmpLocation = new Vector3Int();
        Vector3Int tmpSize = new Vector3Int();
        for(int x=0;x<heightmap.length;x++){
            for(int z=0;z<heightmap[0].length;z++){
                tmpLocation.set(location.getX() + x, location.getY(), location.getZ() + z);
                tmpSize.set(1, heightmap[x][z], 1);
                setBlockArea(tmpLocation, tmpSize, blockClass);
            }
        }
    }
    
    private static final float mapResolution = 50;
    private final PerlinNoise noise = new PerlinNoise(5662);
    //TODO: accept random seed
    
    /**
     *Sets a chunk using the prebuilt noise values.
     * @param location
     */
    public void setChunkFromNoise(Vector3Int location)
    {
        int xOffset = location.getX() * settings.getChunkSizeX();
        int yOffset = location.getY() * settings.getChunkSizeY();
        int zOffset = location.getZ() * settings.getChunkSizeZ();
        
        float xNoiseAdjust;
        float yNoiseAdjust;
        float zNoiseAdjust;
        
        for(int x = 0; x < settings.getChunkSizeX(); x++)
        {
            for(int z = 0; z < settings.getChunkSizeZ(); z++)
            {
                for(int y = 0; y < settings.getChunkSizeY(); y++)
                {
                    xNoiseAdjust = ((x + xOffset) / mapResolution);
                    yNoiseAdjust = ((y + yOffset) / mapResolution);
                    zNoiseAdjust = ((z + zOffset) / mapResolution);
                    double noiseValue = NoiseManager.getNoise(xNoiseAdjust, zNoiseAdjust);
                    if((y + yOffset) <= ((noiseValue) + 25))
                    {
                        if(NoiseManager.getNoise(xNoiseAdjust, yNoiseAdjust, zNoiseAdjust) > 0)
                        {
                            setBlock(new Vector3Int(x + xOffset, y + yOffset, z + zOffset), Block_Grass.class);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Noise manager class.
     */
    private static class NoiseManager
    {
        private static final Random seed = new Random(5662);
        private static final PerlinNoise noise1 = new PerlinNoise(seed.nextInt());
        private static final PerlinNoise noise2 = new PerlinNoise(seed.nextInt());
        private static final PerlinNoise noise3 = new PerlinNoise(seed.nextInt());
        private static final PerlinNoise noise4 = new PerlinNoise(seed.nextInt());
        
        private static final PerlinNoise noise5 = new PerlinNoise(seed.nextInt());
        private static final PerlinNoise noise6 = new PerlinNoise(seed.nextInt());
        private static final PerlinNoise noise7 = new PerlinNoise(seed.nextInt());
        private static final PerlinNoise noise8 = new PerlinNoise(seed.nextInt());
        
        /**
         * retreives one noise value from X, Z
         * @param x
         * @param z
         * @return 
         */
        public static double getNoise(float x, float z)
        {
            return(((noise1.getNoise(x, z) * 20) + (noise2.getNoise(x, z) * 10) + (noise3.getNoise(x, z) * 5) + (noise4.getNoise(x, z) * 2)));
        }
        
        /**
         * retreives one noise value from X, Y, Z
         * @param x
         * @param y
         * @param z
         * @return 
         */
        public static double getNoise(float x, float y, float z)
        {
            float noiseAdjust = 2;
            float xAdj = x * noiseAdjust;
            float yAdj = y * noiseAdjust;
            float zAdj = z * noiseAdjust;
            return(noise4.getNoise(xAdj, yAdj, zAdj) + Math.abs(noise5.getNoise(xAdj * 1.5, yAdj * 1.5, zAdj * 1.5) / 1.1) + noise6.getNoise(xAdj, yAdj, zAdj) / 1.5 + Math.abs(noise7.getNoise(xAdj, yAdj, zAdj)) / 2 + noise8.getNoise(xAdj, yAdj, zAdj) / 4);
        }
    }
    
    /**
     * Sets blokc in a location-size area from noise.
     * @param location
     * @param size
     * @param roughness
     * @param blockClass
     * @deprecated
     */
    @Deprecated
    public void setBlocksFromNoise(Vector3Int location, Vector3Int size, float roughness, Class<? extends Block> blockClass)
    {
        Noise noise = new Noise(null, roughness, size.getX(), size.getZ());
        noise.initialise();
        float gridMinimum = noise.getMinimum();
        float gridLargestDifference = (noise.getMaximum() - gridMinimum);
        float[][] grid = noise.getGrid();
        for(int x=0;x<grid.length;x++)
        {
            float[] row = grid[x];
            for(int z=0;z<row.length;z++)
            {
                /*---Calculation of block height has been summarized to minimize the java heap---
                float gridGroundHeight = (row[z] - gridMinimum);
                float blockHeightInPercents = ((gridGroundHeight * 100) / gridLargestDifference);
                int blockHeight = ((int) ((blockHeightInPercents / 100) * size.getY())) + 1;
                ---*/
                int blockHeight = (((int) (((((row[z] - gridMinimum) * 100) / gridLargestDifference) / 100) * size.getY())) + 1);
                Vector3Int tmpLocation = new Vector3Int();
                for(int y=0; y < blockHeight; y++)
                {
                    tmpLocation.set(location.getX() + x, location.getY() + y, location.getZ() + z);
                    setBlock(tmpLocation, blockClass);
                }
            }
        }
    }
    
    public void setBlocksForMaximumFaces(Vector3Int location, Vector3Int size, Class<? extends Block> blockClass){
        Vector3Int tmpLocation = new Vector3Int();
        for(int x=0;x<size.getX();x++){
            for(int y=0;y<size.getY();y++){
                for(int z=0;z<size.getZ();z++){
                    if(((x ^ y ^ z) & 1) == 1){
                        tmpLocation.set(location.getX() + x, location.getY() + y, location.getZ() + z);
                        setBlock(tmpLocation, blockClass);
                    }
                }
            }
        }
    }

    @Override
    public BlockTerrainControl clone(){
        BlockTerrainControl blockTerrain = new BlockTerrainControl(settings);
        blockTerrain.setBlocksFromTerrain(this);
        return blockTerrain;
    }
    
    public void setBlocksFromTerrain(BlockTerrainControl blockTerrain)
    {
        //CubesSerializer.readFromBytes(this, CubesSerializer.writeToBytes(blockTerrain));
    }
    
    
    
    
    
    
    
    
    
    
    
    public void write(BitOutputStream outputStream) 
    {
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
}

    public void read(BitInputStream inputStream) throws IOException
    {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
