/*
 * $Id$
 * 
 * Copyright (c) 2014, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package modCubes;

import java.util.Random;


/**
 *  Perlin Noise implementation adapted from the book:
 *  Texturing and Modeling a Procedural Approach (such a good book).
 *
 *  @author    Paul Speed
 */
public class PerlinNoise {
/*
    private static final double DELTA = 0.001;
    private static final double DELTA_INV = 1000;

    private static final int B = 0x100;
    private static final int BN = 0xff;

    private static final long N = 0x1000;
    private static final long NP = 12; // 2^N
    private static final int  NM = 0xfff;

    private int seed;

    private int[] p = new int[B + B + 2];
    private double[][] g = new double[B + B + 2][3];
    */
    
    private static final double DELTA = 0.001;
    private static final double DELTA_INV = 1000;

    private static final int B = 0x100;
    private static final int BN = 0xff;

    private static final long N = 0x1000;
    private static final long NP = 12; // 2^N
    private static final int  NM = 0xfff;

    private int seed;

    private int[] p = new int[B + B + 2];
    private double[][] g = new double[B + B + 2][3];

    public PerlinNoise()
    {
        this( 0 );
    }

    public PerlinNoise( int seed )
    {
        setSeed( seed );
    }

    public final void setSeed( int seed )
    {
        this.seed = seed;
        initNoise();
    }

    public int getSeed()
    {
        return( seed );
    }

    private void initNoise()
    {
        int i, j, k;

        // Generate from the specified seed for some predictability
        Random rand = new Random( seed );

        for( i = 0; i < B; i++ )
            {
            p[i] = i;

            for( j = 0; j < 3; j++ )
                {
                g[i][j] = (double)(rand.nextInt(B + B) - B) / B;
                }

            normalize3( g[i] );
            }

        while( (--i) != 0 )
            {
            k = p[i];
            j = rand.nextInt( B );
            p[i] = p[j];
            p[j] = k;
            }

        for( i = 0; i < B + 2; i++ )
            {
            p[B + i] = p[i];

            for( j = 0; j < 3; j++ )
                g[B + i][j] = g[i][j];
            }
    }

    /**
     *  Cubic spline interpolation.
     */
    public static double s_curve( double t )
    {
        return( t * t * (3.0 - 2.0 * t) );
    }

    /**
     *  Linear interpolation.
     */
    private static double lerp( double t, double a, double b )
    {
        return( a + t * (b-a) );
    }

    // basically a dot product
    private static double at3( double rx, double ry, double rz, double[] q )
    {
        return( rx * q[0] + ry * q[1] + rz * q[2] );
    }

    private static double at2( double rx, double ry, double[] q )
    {
        return( rx * q[0] + ry * q[1] );
    }

    private static void normalize3( double[] v )
    {
        double s = Math.sqrt( v[0] * v[0] + v[1] * v[1] + v[2] * v[2] );
        v[0] = v[0] / s;
        v[1] = v[1] / s;
        v[2] = v[2] / s;
    }

    public final double getNoise( double x, double y, double z )
    {
        int bx0, bx1, by0, by1, bz0, bz1, b00, b10, b01, b11;
        double rx0, rx1, ry0, ry1, rz0, rz1, sx, sy, sz, t;
        double a, b, c, d, u, v;

        // Setup x
        t = x + N;
        bx0 = ((int)t) & BN;
        bx1 = (bx0 + 1) & BN;
        rx0 = t - (int)t;
        rx1 = rx0 - 1.0;

        // Setup y
        t = y + N;
        by0 = ((int)t) & BN;
        by1 = (by0 + 1) & BN;
        ry0 = t - (int)t;
        ry1 = ry0 - 1.0;

        // Setup z
        t = z + N;
        bz0 = ((int)t) & BN;
        bz1 = (bz0 + 1) & BN;
        rz0 = t - (int)t;
        rz1 = rz0 - 1.0;

        int i = p[ bx0 ];
        int j = p[ bx1 ];

        b00 = p[ i + by0 ];
        b10 = p[ j + by0 ];
        b01 = p[ i + by1 ];
        b11 = p[ j + by1 ];

        sx = s_curve( rx0 );
        sy = s_curve( ry0 );
        sz = s_curve( rz0 );
        
        u = at3( rx0, ry0, rz0, g[ b00 + bz0 ] );
        v = at3( rx1, ry0, rz0, g[ b10 + bz0 ] );
        a = lerp( sx, u, v );

        u = at3( rx0, ry1, rz0, g[ b01 + bz0 ] );
        v = at3( rx1, ry1, rz0, g[ b11 + bz0 ] );
        b = lerp( sx, u, v );

        c = lerp( sy, a, b ); // interpolate in y at lo z

        u = at3( rx0, ry0, rz1, g[ b00 + bz1 ] );
        v = at3( rx1, ry0, rz1, g[ b10 + bz1 ] );
        a = lerp( sx, u, v );

        u = at3( rx0, ry1, rz1, g[ b01 + bz1 ] );
        v = at3( rx1, ry1, rz1, g[ b11 + bz1 ] );
        b = lerp( sx, u, v );

        d = lerp( sy, a, b ); // interpolate in y at hi z

        return( 1.5 * lerp( sz, c, d ) );
    }

    public final double getNoise( double x, double y )
    {
        int bx0, bx1, by0, by1, b00, b10, b01, b11;
        double rx0, rx1, ry0, ry1, sx, sy, t;
        double a, b, u, v;

        // Setup x
        t = x + N;
        bx0 = ((int)t) & BN;
        bx1 = (bx0 + 1) & BN;
        rx0 = t - (int)t;
        rx1 = rx0 - 1.0;

        // Setup y
        t = y + N;
        by0 = ((int)t) & BN;
        by1 = (by0 + 1) & BN;
        ry0 = t - (int)t;
        ry1 = ry0 - 1.0;


        int i = p[ bx0 ];
        int j = p[ bx1 ];

        b00 = p[ i + by0 ];
        b10 = p[ j + by0 ];
        b01 = p[ i + by1 ];
        b11 = p[ j + by1 ];

        sx = s_curve( rx0 );
        sy = s_curve( ry0 );

        u = at2( rx0, ry0, g[ b00 ] );
        v = at2( rx1, ry0, g[ b10 ] );
        a = lerp( sx, u, v );

        u = at2( rx0, ry1, g[ b01 ] );
        v = at2( rx1, ry1, g[ b11 ] );
        b = lerp( sx, u, v );

        return( 1.5 * lerp( sy, a, b ) );
    }
}